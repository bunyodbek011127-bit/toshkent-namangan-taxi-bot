# Toshkent–Namangan Taxi Telegram bot

Bot mijozdan matnli buyurtma oladi, uni haydovchilar guruhiga yuboradi va haydovchi aynan buyurtma xabariga Reply qilganda javobni mijozga shaxsiy xabar qiladi.

## Fayllar
- `bot.py` — bot va kichik health-check web server
- `requirements.txt` — Python kutubxonalari
- `render.yaml` — Render sozlamalari
- `.gitignore` — maxfiy va vaqtinchalik fayllarni GitHub’dan chetda saqlaydi

## Render’da kerakli environment variables
- `TELEGRAM_BOT_TOKEN` — BotFather bergan maxfiy token
- `GROUP_CHAT_ID` — haydovchilar guruhining raqamli chat ID raqami
- `DATABASE_PATH` — ixtiyoriy, odatda `orders.sqlite3`

Tokenni GitHub kodiga yozmang. Uni faqat Render → Environment bo‘limida kiriting.

## Telegram sozlash
1. BotFather’dan bot tokenini oling va maxfiy saqlang.
2. Botni haydovchilar guruhiga qo‘shing.
3. Bot guruhdagi xabarlarni o‘qiy olishi uchun BotFather’da `/setprivacy` → botni tanlang → `Disable` qiling; keyin botni guruhdan olib qayta qo‘shish talab qilinishi mumkin.
4. `GROUP_CHAT_ID` uchun guruhning raqamli ID raqami kerak. Uni ishonchli usul bilan aniqlab, Render Environment’ga kiriting.
5. Mijoz botga birinchi marta `/start` yuborishi shart, aks holda bot unga shaxsiy xabar yubora olmaydi.

## Muhim cheklovlar
- Render’ning bepul Web Service rejasi uyquga ketishi mumkin; u uzluksiz 24/7 ishlashni kafolatlamaydi.
- Bepul serverning mahalliy fayllari qayta deploy yoki restart vaqtida yo‘qolishi mumkin. Buyurtma bog‘lanishlari doimiy saqlanishi kerak bo‘lsa, doimiy disk yoki tashqi ma’lumotlar bazasini sozlang.
- Bu boshlang‘ich variant matnli buyurtma va matnli haydovchi javoblarini qo‘llaydi.
- Bir xil buyurtmaga bir nechta haydovchi Reply qilsa, ularning har bir javobi mijozga yuboriladi.
