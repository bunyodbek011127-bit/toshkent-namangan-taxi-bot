import asyncio
import logging
import os
import sqlite3
import threading
from flask import Flask, jsonify
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=os.getenv("LOG_LEVEL", "INFO"),
)
logger = logging.getLogger(__name__)

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
GROUP_ID_RAW = os.getenv("GROUP_CHAT_ID", "").strip()
DATABASE_PATH = os.getenv("DATABASE_PATH", "orders.sqlite3")
PORT = int(os.getenv("PORT", "10000"))

if not TOKEN:
    raise RuntimeError("TELEGRAM_BOT_TOKEN environment variable is missing.")
if not GROUP_ID_RAW:
    raise RuntimeError("GROUP_CHAT_ID environment variable is missing.")
try:
    GROUP_ID = int(GROUP_ID_RAW)
except ValueError as exc:
    raise RuntimeError("GROUP_CHAT_ID must be a numeric Telegram chat ID.") from exc

web = Flask(__name__)


def init_db():
    with sqlite3.connect(DATABASE_PATH) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                group_message_id INTEGER PRIMARY KEY,
                customer_chat_id INTEGER NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.commit()


def save_order(group_message_id: int, customer_chat_id: int):
    with sqlite3.connect(DATABASE_PATH) as db:
        db.execute(
            "INSERT OR REPLACE INTO orders (group_message_id, customer_chat_id) VALUES (?, ?)",
            (group_message_id, customer_chat_id),
        )
        db.commit()


def find_customer(group_message_id: int):
    with sqlite3.connect(DATABASE_PATH) as db:
        row = db.execute(
            "SELECT customer_chat_id FROM orders WHERE group_message_id = ?",
            (group_message_id,),
        ).fetchone()
        return row[0] if row else None


@web.get("/")
def home():
    return jsonify(status="ok", service="Toshkent-Namangan Taxi bot")


@web.get("/health")
def health():
    return jsonify(status="healthy"), 200


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_message:
        await update.effective_message.reply_text(
            "Assalomu alaykum! 🚕 Toshkent–Namangan Taxi xizmatiga xush kelibsiz.\n\n"
            "Buyurtmangizni matn ko‘rinishida yuboring. Masalan:\n"
            "Toshkent → Namangan, 2 kishi, bugun soat 18:00."
        )


async def customer_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.effective_message
    if not message or not message.text or message.text.startswith("/"):
        return

    customer = update.effective_user
    customer_label = f"@{customer.username}" if customer and customer.username else "Telegram foydalanuvchisi"
    order_text = (
        "🚕 YANGI TAXI BUYURTMASI\n"
        f"Mijoz: {customer_label}\n"
        f"Buyurtma raqami: #{message.message_id}\n\n"
        f"{message.text}\n\n"
        "Haydovchi: mijozga javob berish uchun shu buyurtma xabariga Reply qiling."
    )

    try:
        sent = await context.bot.send_message(chat_id=GROUP_ID, text=order_text)
        save_order(sent.message_id, message.chat_id)
        await message.reply_text(
            "✅ Buyurtmangiz haydovchilar guruhiga yuborildi.\n"
            "Haydovchi javob berganda sizga shu bot orqali xabar keladi."
        )
    except Exception:
        logger.exception("Could not send customer order to the driver group.")
        await message.reply_text(
            "❌ Buyurtmani yuborishda xatolik yuz berdi. Iltimos, birozdan keyin qayta urinib ko‘ring."
        )


async def driver_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.effective_message
    if not message or not message.reply_to_message:
        return
    if message.chat_id != GROUP_ID:
        return
    if not message.text:
        return
    if message.from_user and message.from_user.is_bot:
        return

    customer_chat_id = find_customer(message.reply_to_message.message_id)
    if not customer_chat_id:
        return

    driver_name = message.from_user.full_name if message.from_user else "Haydovchi"
    try:
        await context.bot.send_message(
            chat_id=customer_chat_id,
            text=f"🚘 Haydovchidan javob ({driver_name}):\n\n{message.text}",
        )
        await message.reply_text("✅ Javob mijozga yuborildi.")
    except Exception:
        logger.exception("Could not deliver driver reply to customer.")
        await message.reply_text(
            "❌ Mijozga xabar yuborilmadi. Mijoz botni avval /start orqali ishga tushirganini tekshiring."
        )


async def telegram_main():
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(
        MessageHandler(filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND, customer_order)
    )
    application.add_handler(
        MessageHandler(filters.ChatType.GROUPS & filters.TEXT & ~filters.COMMAND, driver_reply)
    )

    await application.initialize()
    await application.start()
    if application.updater is None:
        raise RuntimeError("Telegram updater is not available.")
    await application.updater.start_polling(drop_pending_updates=False)
    logger.info("Telegram bot polling started.")
    try:
        await asyncio.Event().wait()
    finally:
        await application.updater.stop()
        await application.stop()
        await application.shutdown()


def run_telegram():
    asyncio.run(telegram_main())


if __name__ == "__main__":
    init_db()
    thread = threading.Thread(target=run_telegram, name="telegram-bot", daemon=True)
    thread.start()
    web.run(host="0.0.0.0", port=PORT)
